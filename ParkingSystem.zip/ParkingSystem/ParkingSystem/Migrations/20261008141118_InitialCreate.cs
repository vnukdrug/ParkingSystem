﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ParkingSystem.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "SpotTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SurchargePercent = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SpotTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tariffs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PricePerHour = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tariffs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserStatuses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    MinReservations = table.Column<int>(type: "int", nullable: false),
                    DiscountPercent = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserStatuses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ParkingSpots",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Number = table.Column<int>(type: "int", nullable: false),
                    TypeId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Row = table.Column<int>(type: "int", nullable: false),
                    Column = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParkingSpots", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ParkingSpots_SpotTypes_TypeId",
                        column: x => x.TypeId,
                        principalTable: "SpotTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Balance = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    ReservationsCount = table.Column<int>(type: "int", nullable: false),
                    StatusId = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_UserStatuses_StatusId",
                        column: x => x.StatusId,
                        principalTable: "UserStatuses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Cars",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    LicensePlate = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Brand = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Model = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cars", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Cars_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Logs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: true),
                    Action = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Details = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IpAddress = table.Column<string>(type: "nvarchar(45)", maxLength: 45, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Logs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Logs_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Type = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Payments_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Reservations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    SpotId = table.Column<int>(type: "int", nullable: false),
                    CarId = table.Column<int>(type: "int", nullable: false),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    DiscountApplied = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Reservations_Cars_CarId",
                        column: x => x.CarId,
                        principalTable: "Cars",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_ParkingSpots_SpotId",
                        column: x => x.SpotId,
                        principalTable: "ParkingSpots",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ParkingSessions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReservationId = table.Column<int>(type: "int", nullable: true),
                    SpotId = table.Column<int>(type: "int", nullable: false),
                    EntryTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExitTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    OperatorId = table.Column<int>(type: "int", nullable: true),
                    TotalAmount = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParkingSessions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ParkingSessions_ParkingSpots_SpotId",
                        column: x => x.SpotId,
                        principalTable: "ParkingSpots",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ParkingSessions_Reservations_ReservationId",
                        column: x => x.ReservationId,
                        principalTable: "Reservations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_ParkingSessions_Users_OperatorId",
                        column: x => x.OperatorId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.InsertData(
                table: "SpotTypes",
                columns: new[] { "Id", "Name", "SurchargePercent" },
                values: new object[,]
                {
                    { 1, "Стандартное", 0m },
                    { 2, "Для инвалидов", 0m },
                    { 3, "VIP", 50m }
                });

            migrationBuilder.InsertData(
                table: "Tariffs",
                columns: new[] { "Id", "IsActive", "Name", "PricePerHour" },
                values: new object[] { 1, true, "Базовый", 100m });

            migrationBuilder.InsertData(
                table: "UserStatuses",
                columns: new[] { "Id", "DiscountPercent", "MinReservations", "Name" },
                values: new object[,]
                {
                    { 1, 0m, 0, "Новичок" },
                    { 2, 3m, 3, "Бронзовый" },
                    { 3, 5m, 10, "Серебряный" },
                    { 4, 10m, 20, "Золотой" }
                });

            migrationBuilder.InsertData(
                table: "ParkingSpots",
                columns: new[] { "Id", "Column", "Number", "Row", "Status", "TypeId" },
                values: new object[,]
                {
                    { 1, 1, 1, 1, 0, 2 },
                    { 2, 2, 2, 1, 0, 2 },
                    { 3, 3, 3, 1, 0, 2 },
                    { 4, 4, 4, 1, 0, 2 },
                    { 5, 5, 5, 1, 0, 2 },
                    { 6, 6, 6, 1, 0, 3 },
                    { 7, 7, 7, 1, 0, 3 },
                    { 8, 8, 8, 1, 0, 3 },
                    { 9, 9, 9, 1, 0, 3 },
                    { 10, 10, 10, 1, 0, 3 },
                    { 11, 11, 11, 1, 0, 1 },
                    { 12, 12, 12, 1, 0, 1 },
                    { 13, 13, 13, 1, 0, 1 },
                    { 14, 14, 14, 1, 0, 1 },
                    { 15, 15, 15, 1, 0, 1 },
                    { 16, 1, 16, 2, 0, 1 },
                    { 17, 2, 17, 2, 0, 1 },
                    { 18, 3, 18, 2, 0, 1 },
                    { 19, 4, 19, 2, 0, 1 },
                    { 20, 5, 20, 2, 0, 1 },
                    { 21, 6, 21, 2, 0, 1 },
                    { 22, 7, 22, 2, 0, 1 },
                    { 23, 8, 23, 2, 0, 1 },
                    { 24, 9, 24, 2, 0, 1 },
                    { 25, 10, 25, 2, 0, 1 },
                    { 26, 11, 26, 2, 0, 1 },
                    { 27, 12, 27, 2, 0, 1 },
                    { 28, 13, 28, 2, 0, 1 },
                    { 29, 14, 29, 2, 0, 1 },
                    { 30, 15, 30, 2, 0, 1 },
                    { 31, 1, 31, 3, 0, 1 },
                    { 32, 2, 32, 3, 0, 1 },
                    { 33, 3, 33, 3, 0, 1 },
                    { 34, 4, 34, 3, 0, 1 },
                    { 35, 5, 35, 3, 0, 1 },
                    { 36, 6, 36, 3, 0, 1 },
                    { 37, 7, 37, 3, 0, 1 },
                    { 38, 8, 38, 3, 0, 1 },
                    { 39, 9, 39, 3, 0, 1 },
                    { 40, 10, 40, 3, 0, 1 },
                    { 41, 11, 41, 3, 0, 1 },
                    { 42, 12, 42, 3, 0, 1 },
                    { 43, 13, 43, 3, 0, 1 },
                    { 44, 14, 44, 3, 0, 1 },
                    { 45, 15, 45, 3, 0, 1 },
                    { 46, 1, 46, 4, 0, 1 },
                    { 47, 2, 47, 4, 0, 1 },
                    { 48, 3, 48, 4, 0, 1 },
                    { 49, 4, 49, 4, 0, 1 },
                    { 50, 5, 50, 4, 0, 1 },
                    { 51, 6, 51, 4, 0, 1 },
                    { 52, 7, 52, 4, 0, 1 },
                    { 53, 8, 53, 4, 0, 1 },
                    { 54, 9, 54, 4, 0, 1 },
                    { 55, 10, 55, 4, 0, 1 },
                    { 56, 11, 56, 4, 0, 1 },
                    { 57, 12, 57, 4, 0, 1 },
                    { 58, 13, 58, 4, 0, 1 },
                    { 59, 14, 59, 4, 0, 1 },
                    { 60, 15, 60, 4, 0, 1 },
                    { 61, 1, 61, 5, 0, 1 },
                    { 62, 2, 62, 5, 0, 1 },
                    { 63, 3, 63, 5, 0, 1 },
                    { 64, 4, 64, 5, 0, 1 },
                    { 65, 5, 65, 5, 0, 1 },
                    { 66, 6, 66, 5, 0, 1 },
                    { 67, 7, 67, 5, 0, 1 },
                    { 68, 8, 68, 5, 0, 1 },
                    { 69, 9, 69, 5, 0, 1 },
                    { 70, 10, 70, 5, 0, 1 },
                    { 71, 11, 71, 5, 0, 1 },
                    { 72, 12, 72, 5, 0, 1 },
                    { 73, 13, 73, 5, 0, 1 },
                    { 74, 14, 74, 5, 0, 1 },
                    { 75, 15, 75, 5, 0, 1 },
                    { 76, 1, 76, 6, 0, 1 },
                    { 77, 2, 77, 6, 0, 1 },
                    { 78, 3, 78, 6, 0, 1 },
                    { 79, 4, 79, 6, 0, 1 },
                    { 80, 5, 80, 6, 0, 1 },
                    { 81, 6, 81, 6, 0, 1 },
                    { 82, 7, 82, 6, 0, 1 },
                    { 83, 8, 83, 6, 0, 1 },
                    { 84, 9, 84, 6, 0, 1 },
                    { 85, 10, 85, 6, 0, 1 },
                    { 86, 11, 86, 6, 0, 1 },
                    { 87, 12, 87, 6, 0, 1 },
                    { 88, 13, 88, 6, 0, 1 },
                    { 89, 14, 89, 6, 0, 1 },
                    { 90, 15, 90, 6, 0, 1 },
                    { 91, 1, 91, 7, 0, 1 },
                    { 92, 2, 92, 7, 0, 1 },
                    { 93, 3, 93, 7, 0, 1 },
                    { 94, 4, 94, 7, 0, 1 },
                    { 95, 5, 95, 7, 0, 1 },
                    { 96, 6, 96, 7, 0, 1 },
                    { 97, 7, 97, 7, 0, 1 },
                    { 98, 8, 98, 7, 0, 1 },
                    { 99, 9, 99, 7, 0, 1 },
                    { 100, 10, 100, 7, 0, 1 },
                    { 101, 11, 101, 7, 0, 1 },
                    { 102, 12, 102, 7, 0, 1 },
                    { 103, 13, 103, 7, 0, 1 },
                    { 104, 14, 104, 7, 0, 1 },
                    { 105, 15, 105, 7, 0, 1 },
                    { 106, 1, 106, 8, 0, 1 },
                    { 107, 2, 107, 8, 0, 1 },
                    { 108, 3, 108, 8, 0, 1 },
                    { 109, 4, 109, 8, 0, 1 },
                    { 110, 5, 110, 8, 0, 1 },
                    { 111, 6, 111, 8, 0, 1 },
                    { 112, 7, 112, 8, 0, 1 },
                    { 113, 8, 113, 8, 0, 1 },
                    { 114, 9, 114, 8, 0, 1 },
                    { 115, 10, 115, 8, 0, 1 },
                    { 116, 11, 116, 8, 0, 1 },
                    { 117, 12, 117, 8, 0, 1 },
                    { 118, 13, 118, 8, 0, 1 },
                    { 119, 14, 119, 8, 0, 1 },
                    { 120, 15, 120, 8, 0, 1 },
                    { 121, 1, 121, 9, 0, 1 },
                    { 122, 2, 122, 9, 0, 1 },
                    { 123, 3, 123, 9, 0, 1 },
                    { 124, 4, 124, 9, 0, 1 },
                    { 125, 5, 125, 9, 0, 1 },
                    { 126, 6, 126, 9, 0, 1 },
                    { 127, 7, 127, 9, 0, 1 },
                    { 128, 8, 128, 9, 0, 1 },
                    { 129, 9, 129, 9, 0, 1 },
                    { 130, 10, 130, 9, 0, 1 },
                    { 131, 11, 131, 9, 0, 1 },
                    { 132, 12, 132, 9, 0, 1 },
                    { 133, 13, 133, 9, 0, 1 },
                    { 134, 14, 134, 9, 0, 1 },
                    { 135, 15, 135, 9, 0, 1 },
                    { 136, 1, 136, 10, 0, 1 },
                    { 137, 2, 137, 10, 0, 1 },
                    { 138, 3, 138, 10, 0, 1 },
                    { 139, 4, 139, 10, 0, 1 },
                    { 140, 5, 140, 10, 0, 1 },
                    { 141, 6, 141, 10, 0, 1 },
                    { 142, 7, 142, 10, 0, 1 },
                    { 143, 8, 143, 10, 0, 1 },
                    { 144, 9, 144, 10, 0, 1 },
                    { 145, 10, 145, 10, 0, 1 },
                    { 146, 11, 146, 10, 0, 1 },
                    { 147, 12, 147, 10, 0, 1 },
                    { 148, 13, 148, 10, 0, 1 },
                    { 149, 14, 149, 10, 0, 1 },
                    { 150, 15, 150, 10, 0, 1 }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Balance", "CreatedAt", "Email", "PasswordHash", "ReservationsCount", "Role", "StatusId" },
                values: new object[] { 1, 0m, new DateTime(2026, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "admin@parking.ru", "AQAAAAEAACcQAAAAEK...", 0, "Администратор", 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Cars_UserId",
                table: "Cars",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Logs_UserId",
                table: "Logs",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_ParkingSessions_OperatorId",
                table: "ParkingSessions",
                column: "OperatorId");

            migrationBuilder.CreateIndex(
                name: "IX_ParkingSessions_ReservationId",
                table: "ParkingSessions",
                column: "ReservationId");

            migrationBuilder.CreateIndex(
                name: "IX_ParkingSessions_SpotId",
                table: "ParkingSessions",
                column: "SpotId");

            migrationBuilder.CreateIndex(
                name: "IX_ParkingSpots_TypeId",
                table: "ParkingSpots",
                column: "TypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_UserId",
                table: "Payments",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_CarId",
                table: "Reservations",
                column: "CarId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_SpotId",
                table: "Reservations",
                column: "SpotId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_UserId",
                table: "Reservations",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_StatusId",
                table: "Users",
                column: "StatusId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Logs");

            migrationBuilder.DropTable(
                name: "ParkingSessions");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "Tariffs");

            migrationBuilder.DropTable(
                name: "Reservations");

            migrationBuilder.DropTable(
                name: "Cars");

            migrationBuilder.DropTable(
                name: "ParkingSpots");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "SpotTypes");

            migrationBuilder.DropTable(
                name: "UserStatuses");
        }
    }
}
