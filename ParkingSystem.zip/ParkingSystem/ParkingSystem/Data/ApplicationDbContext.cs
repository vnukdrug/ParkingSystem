﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Models;

namespace ParkingSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<UserStatus> UserStatuses { get; set; }
        public DbSet<SpotType> SpotTypes { get; set; }
        public DbSet<ParkingSpot> ParkingSpots { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Tariff> Tariffs { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<ParkingSession> ParkingSessions { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Log> Logs { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<SupportTicket> SupportTickets { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // User → UserStatus
            builder.Entity<User>()
                .HasOne(u => u.Status)
                .WithMany(s => s.Users)
                .HasForeignKey(u => u.StatusId)
                .OnDelete(DeleteBehavior.SetNull);

            // Car → User
            builder.Entity<Car>()
                .HasOne(c => c.User)
                .WithMany(u => u.Cars)
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Reservation → User
            builder.Entity<Reservation>()
                .HasOne(r => r.User)
                .WithMany(u => u.Reservations)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Reservation → Spot
            builder.Entity<Reservation>()
                .HasOne(r => r.Spot)
                .WithMany(s => s.Reservations)
                .HasForeignKey(r => r.SpotId)
                .OnDelete(DeleteBehavior.Restrict);

            // Reservation → Car
            builder.Entity<Reservation>()
                .HasOne(r => r.Car)
                .WithMany(c => c.Reservations)
                .HasForeignKey(r => r.CarId)
                .OnDelete(DeleteBehavior.Restrict);

            // Payment → User
            builder.Entity<Payment>()
                .HasOne(p => p.User)
                .WithMany(u => u.Payments)
                .HasForeignKey(p => p.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Log → User
            builder.Entity<Log>()
                .HasOne(l => l.User)
                .WithMany(u => u.Logs)
                .HasForeignKey(l => l.UserId)
                .OnDelete(DeleteBehavior.SetNull);

            // ParkingSpot → SpotType
            builder.Entity<ParkingSpot>()
                .HasOne(s => s.Type)
                .WithMany(t => t.Spots)
                .HasForeignKey(s => s.TypeId)
                .OnDelete(DeleteBehavior.Restrict);

            // ParkingSession → Reservation
            builder.Entity<ParkingSession>()
                .HasOne(ps => ps.Reservation)
                .WithMany()
                .HasForeignKey(ps => ps.ReservationId)
                .OnDelete(DeleteBehavior.SetNull);

            // ParkingSession → Spot
            builder.Entity<ParkingSession>()
                .HasOne(ps => ps.Spot)
                .WithMany()
                .HasForeignKey(ps => ps.SpotId)
                .OnDelete(DeleteBehavior.Restrict);

            // ParkingSession → Operator
            builder.Entity<ParkingSession>()
                .HasOne(ps => ps.Operator)
                .WithMany()
                .HasForeignKey(ps => ps.OperatorId)
                .OnDelete(DeleteBehavior.SetNull);

            // Notification → User
            builder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany()
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Cascade);
            // SupportTicket → User
            builder.Entity<SupportTicket>()
                .HasOne(t => t.User)
                .WithMany()
                .HasForeignKey(t => t.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Точность decimal
            builder.Entity<User>().Property(u => u.Balance).HasPrecision(18, 2);
            builder.Entity<UserStatus>().Property(s => s.DiscountPercent).HasPrecision(5, 2);
            builder.Entity<SpotType>().Property(t => t.SurchargePercent).HasPrecision(5, 2);
            builder.Entity<Tariff>().Property(t => t.PricePerHour).HasPrecision(18, 2);
            builder.Entity<Reservation>().Property(r => r.TotalPrice).HasPrecision(18, 2);
            builder.Entity<Reservation>().Property(r => r.DiscountApplied).HasPrecision(18, 2);
            builder.Entity<ParkingSession>().Property(s => s.TotalAmount).HasPrecision(18, 2);
            builder.Entity<Payment>().Property(p => p.Amount).HasPrecision(18, 2);

            SeedData(builder);
        }

        private void SeedData(ModelBuilder builder)
        {
            builder.Entity<UserStatus>().HasData(
                new UserStatus { Id = 1, Name = "Новичок", MinReservations = 0, DiscountPercent = 0 },
                new UserStatus { Id = 2, Name = "Бронзовый", MinReservations = 3, DiscountPercent = 3 },
                new UserStatus { Id = 3, Name = "Серебряный", MinReservations = 10, DiscountPercent = 5 },
                new UserStatus { Id = 4, Name = "Золотой", MinReservations = 20, DiscountPercent = 10 }
            );

            builder.Entity<SpotType>().HasData(
                new SpotType { Id = 1, Name = "Стандартное", SurchargePercent = 0 },
                new SpotType { Id = 2, Name = "Для инвалидов", SurchargePercent = 0 },
                new SpotType { Id = 3, Name = "VIP", SurchargePercent = 50 }
            );

            builder.Entity<Tariff>().HasData(
                new Tariff { Id = 1, Name = "Базовый", PricePerHour = 100, IsActive = true }
            );

            var spots = new List<ParkingSpot>();
            int id = 1;
            for (int row = 1; row <= 10; row++)
            {
                for (int col = 1; col <= 15; col++)
                {
                    int typeId = 1;
                    if (row == 1 && col <= 5) typeId = 2;
                    if (row == 1 && col >= 6 && col <= 10) typeId = 3;

                    spots.Add(new ParkingSpot
                    {
                        Id = id,
                        Number = id,
                        TypeId = typeId,
                        Status = SpotStatus.Free,
                        Row = row,
                        Column = col
                    });
                    id++;
                }
            }
            builder.Entity<ParkingSpot>().HasData(spots);
        }
    }
}