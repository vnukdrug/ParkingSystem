﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class Reservation
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }
        public User? User { get; set; }

        public int SpotId { get; set; }
        public ParkingSpot? Spot { get; set; }

        public int CarId { get; set; }
        public Car? Car { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        public decimal TotalPrice { get; set; }

        public decimal DiscountApplied { get; set; }

        public ReservationStatus Status { get; set; } = ReservationStatus.Active;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [MaxLength(500)]
        public string? CancelReason { get; set; }
    }
}