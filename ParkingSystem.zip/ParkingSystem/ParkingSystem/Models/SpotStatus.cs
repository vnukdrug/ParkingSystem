﻿namespace ParkingSystem.Models
{
    public enum SpotStatus
    {
        Free = 0,
        Reserved = 1,
        Occupied = 2,
        Maintenance = 3
    }
}