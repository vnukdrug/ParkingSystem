﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class UserStatus
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;

        public int MinReservations { get; set; }

        public decimal DiscountPercent { get; set; }

        public ICollection<User> Users { get; set; } = new List<User>();
    }
}