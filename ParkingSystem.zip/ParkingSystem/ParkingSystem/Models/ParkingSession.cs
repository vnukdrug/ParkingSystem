﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class ParkingSession
    {
        [Key]
        public int Id { get; set; }

        public int? ReservationId { get; set; }
        public Reservation? Reservation { get; set; }

        public int SpotId { get; set; }
        public ParkingSpot? Spot { get; set; }

        public DateTime EntryTime { get; set; }

        public DateTime? ExitTime { get; set; }

        public int? OperatorId { get; set; }
        public User? Operator { get; set; }

        public decimal? TotalAmount { get; set; }
    }
}