﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Role { get; set; } = "Пользователь";

        // ФИО
        [MaxLength(50)]
        public string? LastName { get; set; }

        [MaxLength(50)]
        public string? FirstName { get; set; }

        [MaxLength(50)]
        public string? MiddleName { get; set; }

        // Паспорт
        [MaxLength(4)]
        public string? PassportSeries { get; set; }

        [MaxLength(6)]
        public string? PassportNumber { get; set; }

        // Контакты
        [MaxLength(20)]
        public string? Phone { get; set; }

        // Фото
        [MaxLength(255)]
        public string? PhotoPath { get; set; }

        public bool IsActive { get; set; } = true;

        public decimal Balance { get; set; } = 0;

        public int ReservationsCount { get; set; } = 0;

        public int? StatusId { get; set; }
        public UserStatus? Status { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<Car> Cars { get; set; } = new List<Car>();
        public ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
        public ICollection<Payment> Payments { get; set; } = new List<Payment>();
        public ICollection<Log> Logs { get; set; } = new List<Log>();
    }
}