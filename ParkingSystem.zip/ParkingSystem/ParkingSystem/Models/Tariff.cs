﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class Tariff
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        public decimal PricePerHour { get; set; }

        public bool IsActive { get; set; } = true;
    }
}