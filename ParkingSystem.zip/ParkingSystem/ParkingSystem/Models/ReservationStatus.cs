﻿namespace ParkingSystem.Models
{
    public enum ReservationStatus
    {
        Active = 0,
        Completed = 1,
        Cancelled = 2
    }
}