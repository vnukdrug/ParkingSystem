﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class ParkingSpot
    {
        [Key]
        public int Id { get; set; }

        public int Number { get; set; }

        public int TypeId { get; set; }
        public SpotType? Type { get; set; }

        public SpotStatus Status { get; set; } = SpotStatus.Free;

        public int Row { get; set; }

        public int Column { get; set; }

        public ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
    }
}