﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class SpotType
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;

        public decimal SurchargePercent { get; set; }

        public ICollection<ParkingSpot> Spots { get; set; } = new List<ParkingSpot>();
    }
}