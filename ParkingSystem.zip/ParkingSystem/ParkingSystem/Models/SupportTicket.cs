﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class SupportTicket
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }
        public User? User { get; set; }

        [Required]
        [MaxLength(150)]
        public string Subject { get; set; } = string.Empty;

        [Required]
        [MaxLength(2000)]
        public string Message { get; set; } = string.Empty;

        [MaxLength(2000)]
        public string? AdminReply { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? RepliedAt { get; set; }

        public int? RepliedByUserId { get; set; }

        [MaxLength(50)]
        public string Status { get; set; } = "Открыт"; // Открыт, Отвечен, Закрыт
    }
}