﻿namespace ParkingSystem.Models
{
    public enum PaymentType
    {
        TopUp = 0,
        Charge = 1
    }
}