﻿using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }
        public User? User { get; set; }

        public decimal Amount { get; set; }

        public PaymentType Type { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [MaxLength(255)]
        public string? Description { get; set; }
    }
}