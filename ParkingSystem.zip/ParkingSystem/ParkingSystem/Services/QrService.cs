﻿using QRCoder;

namespace ParkingSystem.Services
{
    public class QrService
    {
        // Генерация QR-кода → PNG байты
        public byte[] GenerateQr(string text)
        {
            using var qrGenerator = new QRCodeGenerator();
            using var qrCodeData = qrGenerator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new PngByteQRCode(qrCodeData);
            return qrCode.GetGraphic(10);
        }

        // Формирование текста для QR по брони
        public string BuildReservationQrText(int reservationId, string licensePlate, int spotNumber)
        {
            return $"PARKING|{reservationId}|{licensePlate}|{spotNumber}";
        }
    }
}