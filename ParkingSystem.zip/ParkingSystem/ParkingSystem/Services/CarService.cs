﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class CarService
    {
        private readonly ApplicationDbContext _context;

        public CarService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Car>> GetUserCarsAsync(int userId)
        {
            return await _context.Cars
                .Where(c => c.UserId == userId)
                .ToListAsync();
        }

        public async Task<Car> AddCarAsync(int userId, string licensePlate, string? brand, string? model)
        {
            var car = new Car
            {
                UserId = userId,
                LicensePlate = licensePlate,
                Brand = brand,
                Model = model
            };

            _context.Cars.Add(car);
            await _context.SaveChangesAsync();
            return car;
        }

        public async Task<bool> DeleteCarAsync(int carId, int userId)
        {
            var car = await _context.Cars.FirstOrDefaultAsync(c => c.Id == carId && c.UserId == userId);
            if (car == null) return false;

            _context.Cars.Remove(car);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}