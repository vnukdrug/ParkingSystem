﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class ReservationService
    {
        private readonly ApplicationDbContext _context;

        public ReservationService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<decimal> CalculatePriceAsync(int spotId, int userId, DateTime start, DateTime end)
        {
            var spot = await _context.ParkingSpots
                .Include(s => s.Type)
                .FirstAsync(s => s.Id == spotId);

            var user = await _context.Users
                .Include(u => u.Status)
                .FirstAsync(u => u.Id == userId);

            var tariff = await _context.Tariffs.FirstAsync(t => t.IsActive);

            var hours = (decimal)(end - start).TotalHours;
            if (hours < 1) hours = 1;

            var basePrice = hours * tariff.PricePerHour;
            var surcharge = basePrice * (spot.Type?.SurchargePercent ?? 0) / 100;
            var priceWithSurcharge = basePrice + surcharge;
            var discount = priceWithSurcharge * (user.Status?.DiscountPercent ?? 0) / 100;
            var finalPrice = priceWithSurcharge - discount;

            return Math.Round(finalPrice, 2);
        }

        public async Task<(bool success, string message, Reservation? reservation)> CreateAsync(
            int userId, int spotId, int carId, DateTime start, DateTime end)
        {
            var user = await _context.Users
                .Include(u => u.Status)
                .FirstAsync(u => u.Id == userId);

            var spot = await _context.ParkingSpots
                .Include(s => s.Type)
                .FirstAsync(s => s.Id == spotId);

            if (spot.Status != SpotStatus.Free)
                return (false, "Место уже занято", null);

            if (end <= start)
                return (false, "Время окончания должно быть позже времени начала", null);

            if (start < DateTime.UtcNow.AddMinutes(-5))
                return (false, "Нельзя бронировать на прошедшее время", null);

            var price = await CalculatePriceAsync(spotId, userId, start, end);

            if (user.Balance < price)
                return (false, $"Недостаточно средств. Требуется {price} руб., у вас {user.Balance} руб.", null);

            user.Balance -= price;
            spot.Status = SpotStatus.Reserved;

            var reservation = new Reservation
            {
                UserId = userId,
                SpotId = spotId,
                CarId = carId,
                StartTime = start,
                EndTime = end,
                TotalPrice = price,
                DiscountApplied = price * (user.Status?.DiscountPercent ?? 0) / 100,
                Status = ReservationStatus.Active,
                CreatedAt = DateTime.UtcNow
            };

            _context.Reservations.Add(reservation);

            _context.Payments.Add(new Payment
            {
                UserId = userId,
                Amount = price,
                Type = PaymentType.Charge,
                CreatedAt = DateTime.UtcNow,
                Description = $"Оплата бронирования места №{spot.Number}"
            });

            _context.Notifications.Add(new Notification
            {
                UserId = userId,
                Title = "Бронь создана",
                Message = $"Место №{spot.Number} забронировано на {start.ToLocalTime():dd.MM.yyyy HH:mm} — {end.ToLocalTime():dd.MM.yyyy HH:mm}. Сумма: {price} ₽.",
                Type = "success",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            return (true, "Бронирование успешно создано", reservation);
        }

        public async Task<(bool success, string message, decimal refund)> CancelAsync(int reservationId, int userId, string? reason = null)
        {
            var reservation = await _context.Reservations
                .Include(r => r.Spot)
                .FirstOrDefaultAsync(r => r.Id == reservationId);

            if (reservation == null)
                return (false, "Бронь не найдена", 0);

            if (reservation.UserId != userId)
                return (false, "Это не ваша бронь", 0);

            if (reservation.Status != ReservationStatus.Active)
                return (false, "Бронь нельзя отменить (уже завершена или отменена)", 0);

            var hasSession = await _context.ParkingSessions
                .AnyAsync(s => s.ReservationId == reservationId);

            if (hasSession)
                return (false, "Нельзя отменить бронь — въезд уже зарегистрирован. Обратитесь к оператору.", 0);

            decimal commission = Math.Round(reservation.TotalPrice * 0.10m, 2);
            decimal refund = reservation.TotalPrice - commission;

            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                return (false, "Пользователь не найден", 0);

            user.Balance += refund;

            if (reservation.Spot != null)
                reservation.Spot.Status = SpotStatus.Free;

            reservation.Status = ReservationStatus.Cancelled;
            reservation.CancelReason = string.IsNullOrWhiteSpace(reason) ? "Без указания причины" : reason;

            _context.Payments.Add(new Payment
            {
                UserId = userId,
                Amount = refund,
                Type = PaymentType.TopUp,
                CreatedAt = DateTime.UtcNow,
                Description = $"Возврат за отмену брони №{reservation.Id} (комиссия {commission:F2} руб.)"
            });

            _context.Notifications.Add(new Notification
            {
                UserId = userId,
                Title = "Бронь отменена",
                Message = $"Возврат: {refund:F2} ₽ (комиссия {commission:F2} ₽). Причина: {reservation.CancelReason}",
                Type = "warning",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            return (true, $"Бронь отменена. Возврат: {refund:F2} руб. (комиссия {commission:F2} руб.)", refund);
        }

        public async Task<List<Reservation>> GetUserReservationsAsync(int userId)
        {
            return await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
        }
    }
}