﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public static class DbInitializer
    {
        public static async Task SeedUsersAsync(ApplicationDbContext context)
        {
            var existingEmails = await context.Users.Select(u => u.Email).ToListAsync();

            var users = new List<User>();

            if (!existingEmails.Contains("admin"))
            {
                users.Add(new User
                {
                    Email = "admin",
                    PasswordHash = PasswordHasher.Hash("1"),
                    Role = "Администратор",
                    LastName = "Админов",
                    FirstName = "Админ",
                    MiddleName = "Админович",
                    PassportSeries = "1234",
                    PassportNumber = "567890",
                    Phone = "+7 (999) 000-00-01",
                    Balance = 10000,
                    ReservationsCount = 0,
                    StatusId = 4,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                });
            }

            if (!existingEmails.Contains("operator"))
            {
                users.Add(new User
                {
                    Email = "operator",
                    PasswordHash = PasswordHasher.Hash("1"),
                    Role = "Оператор",
                    LastName = "Операторов",
                    FirstName = "Оператор",
                    MiddleName = "Операторович",
                    PassportSeries = "1234",
                    PassportNumber = "567891",
                    Phone = "+7 (999) 000-00-02",
                    Balance = 0,
                    ReservationsCount = 0,
                    StatusId = 1,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                });
            }

            if (!existingEmails.Contains("user"))
            {
                users.Add(new User
                {
                    Email = "user",
                    PasswordHash = PasswordHasher.Hash("1"),
                    Role = "Пользователь",
                    LastName = "Пользователев",
                    FirstName = "Пользователь",
                    MiddleName = "Пользователевич",
                    PassportSeries = "1234",
                    PassportNumber = "567892",
                    Phone = "+7 (999) 000-00-03",
                    Balance = 5000,
                    ReservationsCount = 0,
                    StatusId = 1,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                });
            }

            if (users.Any())
            {
                context.Users.AddRange(users);
                await context.SaveChangesAsync();
            }
        }
    }
}