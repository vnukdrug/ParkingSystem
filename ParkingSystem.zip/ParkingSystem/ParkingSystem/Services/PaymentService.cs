﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class PaymentService
    {
        private readonly ApplicationDbContext _context;

        public PaymentService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Payment>> GetUserPaymentsAsync(int userId)
        {
            return await _context.Payments
                .Where(p => p.UserId == userId)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<(List<Payment> items, int totalCount)> GetUserPaymentsPagedAsync(int userId, int page, int perPage)
        {
            var query = _context.Payments
                .Where(p => p.UserId == userId)
                .OrderByDescending(p => p.CreatedAt);

            var total = await query.CountAsync();
            var items = await query
                .Skip((page - 1) * perPage)
                .Take(perPage)
                .ToListAsync();

            return (items, total);
        }

        public async Task<(List<Payment> items, int totalCount)> GetUserPaymentsFilteredAsync(
            int userId,
            int page,
            int perPage,
            string? typeFilter = null,
            DateTime? dateFrom = null,
            DateTime? dateTo = null)
        {
            var query = _context.Payments
                .Where(p => p.UserId == userId)
                .AsQueryable();

            if (!string.IsNullOrEmpty(typeFilter))
            {
                if (typeFilter == "topup")
                    query = query.Where(p => p.Type == PaymentType.TopUp);
                else if (typeFilter == "charge")
                    query = query.Where(p => p.Type == PaymentType.Charge);
            }

            if (dateFrom.HasValue)
                query = query.Where(p => p.CreatedAt >= dateFrom.Value);

            if (dateTo.HasValue)
                query = query.Where(p => p.CreatedAt <= dateTo.Value.AddDays(1));

            query = query.OrderByDescending(p => p.CreatedAt);

            var total = await query.CountAsync();
            var items = await query
                .Skip((page - 1) * perPage)
                .Take(perPage)
                .ToListAsync();

            return (items, total);
        }

        public async Task<bool> TopUpBalanceAsync(int userId, decimal amount)
        {
            if (amount <= 0) return false;

            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.Balance += amount;

            _context.Payments.Add(new Payment
            {
                UserId = userId,
                Amount = amount,
                Type = PaymentType.TopUp,
                CreatedAt = DateTime.UtcNow,
                Description = $"Пополнение баланса на {amount} руб."
            });

            await _context.SaveChangesAsync();
            return true;
        }
    }
}