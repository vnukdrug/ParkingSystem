﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;

namespace ParkingSystem.Services
{
    public class StatsService
    {
        private readonly ApplicationDbContext _context;

        public StatsService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<(int todayEntries, int todayCompleted, double todayLoadPercent, decimal todayRevenue, int totalUsers)>
            GetPublicStatsAsync()
        {
            var todayStart = DateTime.UtcNow.Date;
            var todayEnd = todayStart.AddDays(1);

            var todayEntries = await _context.ParkingSessions
                .CountAsync(s => s.EntryTime >= todayStart && s.EntryTime < todayEnd);

            var todayCompleted = await _context.ParkingSessions
                .CountAsync(s => s.ExitTime != null && s.ExitTime >= todayStart && s.ExitTime < todayEnd);

            var todayRevenue = await _context.Payments
                .Where(p => p.Type == Models.PaymentType.Charge
                            && p.CreatedAt >= todayStart
                            && p.CreatedAt < todayEnd)
                .SumAsync(p => (decimal?)p.Amount) ?? 0;

            var totalSpots = await _context.ParkingSpots.CountAsync();
            var occupiedNow = await _context.ParkingSpots
                .CountAsync(s => s.Status == Models.SpotStatus.Occupied || s.Status == Models.SpotStatus.Reserved);

            double loadPercent = totalSpots > 0
                ? Math.Round((double)occupiedNow / totalSpots * 100, 1)
                : 0;

            var totalUsers = await _context.Users.CountAsync();

            return (todayEntries, todayCompleted, loadPercent, todayRevenue, totalUsers);
        }
    }
}