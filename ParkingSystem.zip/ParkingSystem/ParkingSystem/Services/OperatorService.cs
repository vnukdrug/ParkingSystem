﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class OperatorService
    {
        private readonly ApplicationDbContext _context;

        public OperatorService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Активные брони (только те, по которым ещё нет активного въезда)
        public async Task<List<Reservation>> GetActiveReservationsAsync()
        {
            // ID броней, по которым есть активная сессия (въехал, но ещё не выехал)
            var busyReservationIds = await _context.ParkingSessions
                .Where(s => s.ReservationId != null && s.ExitTime == null)
                .Select(s => s.ReservationId!.Value)
                .ToListAsync();

            return await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Include(r => r.User)
                .Where(r => r.Status == ReservationStatus.Active
                            && !busyReservationIds.Contains(r.Id))
                .OrderBy(r => r.StartTime)
                .ToListAsync();
        }

        // Получить бронь по Id (для QR)
        public async Task<Reservation?> GetReservationByIdAsync(int id)
        {
            return await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        // Регистрация въезда
        public async Task<(bool success, string message)> RegisterEntryAsync(int reservationId, int operatorId)
        {
            var reservation = await _context.Reservations
                .Include(r => r.Spot)
                .FirstOrDefaultAsync(r => r.Id == reservationId);

            if (reservation == null)
                return (false, "Бронь не найдена");

            if (reservation.Status != ReservationStatus.Active)
                return (false, "Бронь неактивна");

            var existingSession = await _context.ParkingSessions
                .FirstOrDefaultAsync(s => s.ReservationId == reservationId && s.ExitTime == null);

            if (existingSession != null)
                return (false, "Въезд уже зарегистрирован");

            var session = new ParkingSession
            {
                ReservationId = reservationId,
                SpotId = reservation.SpotId,
                EntryTime = DateTime.UtcNow,
                OperatorId = operatorId
            };

            _context.ParkingSessions.Add(session);

            if (reservation.Spot != null)
                reservation.Spot.Status = SpotStatus.Occupied;

            await _context.SaveChangesAsync();
            return (true, "Въезд зарегистрирован");
        }

        // Регистрация выезда
        public async Task<(bool success, string message, decimal total)> RegisterExitAsync(int sessionId, int operatorId)
        {
            var session = await _context.ParkingSessions
                .Include(s => s.Spot)
                    .ThenInclude(sp => sp!.Type)
                .Include(s => s.Reservation)
                    .ThenInclude(r => r!.User)
                        .ThenInclude(u => u!.Status)
                .FirstOrDefaultAsync(s => s.Id == sessionId);

            if (session == null)
                return (false, "Сессия не найдена", 0);

            if (session.ExitTime != null)
                return (false, "Выезд уже зарегистрирован", 0);

            if (session.Reservation == null)
                return (false, "Бронь не найдена", 0);

            var user = session.Reservation.User;
            if (user == null)
                return (false, "Пользователь не найден", 0);

            session.ExitTime = DateTime.UtcNow;
            session.OperatorId = operatorId;

            var factHours = (decimal)(session.ExitTime.Value - session.EntryTime).TotalHours;
            if (factHours < 0.25m) factHours = 0.25m;

            var tariff = await _context.Tariffs.FirstAsync(t => t.IsActive);

            var basePrice = factHours * tariff.PricePerHour;
            var surcharge = basePrice * (session.Spot?.Type?.SurchargePercent ?? 0) / 100;
            var priceWithSurcharge = basePrice + surcharge;
            var discount = priceWithSurcharge * (user.Status?.DiscountPercent ?? 0) / 100;
            var finalPrice = Math.Round(priceWithSurcharge - discount, 2);

            var prepaid = session.Reservation.TotalPrice;
            var diff = finalPrice - prepaid;

            if (diff > 0)
            {
                if (user.Balance < diff)
                    return (false, $"Недостаточно средств для доплаты. Требуется {diff:F2} руб., у вас {user.Balance:F2} руб.", 0);

                user.Balance -= diff;
                _context.Payments.Add(new Payment
                {
                    UserId = user.Id,
                    Amount = diff,
                    Type = PaymentType.Charge,
                    CreatedAt = DateTime.UtcNow,
                    Description = $"Доплата за превышение времени парковки (сессия {session.Id})"
                });
            }
            else if (diff < 0)
            {
                var refundAmount = Math.Abs(diff);
                user.Balance += refundAmount;
                _context.Payments.Add(new Payment
                {
                    UserId = user.Id,
                    Amount = refundAmount,
                    Type = PaymentType.TopUp,
                    CreatedAt = DateTime.UtcNow,
                    Description = $"Возврат за неиспользованное время (сессия {session.Id})"
                });
            }

            session.TotalAmount = finalPrice;
            session.Reservation.Status = ReservationStatus.Completed;

            if (session.Spot != null)
                session.Spot.Status = SpotStatus.Free;

            user.ReservationsCount++;

            var statuses = await _context.UserStatuses
                .OrderByDescending(s => s.MinReservations)
                .ToListAsync();

            var newStatus = statuses.FirstOrDefault(s => user.ReservationsCount >= s.MinReservations);

            if (newStatus != null && newStatus.Id != user.StatusId)
            {
                user.StatusId = newStatus.Id;

                _context.Notifications.Add(new Notification
                {
                    UserId = user.Id,
                    Title = "Повышение статуса лояльности!",
                    Message = $"Поздравляем! Ваш статус повышен до «{newStatus.Name}». Скидка на бронирование: {newStatus.DiscountPercent}%.",
                    Type = "success",
                    CreatedAt = DateTime.UtcNow
                });
            }

            var notificationMsg = $"Стоимость парковки: {finalPrice:F2} ₽.";
            if (diff > 0)
                notificationMsg += $" Списана доплата: {diff:F2} ₽.";
            else if (diff < 0)
                notificationMsg += $" Возвращено: {Math.Abs(diff):F2} ₽.";

            _context.Notifications.Add(new Notification
            {
                UserId = user.Id,
                Title = "Выезд зарегистрирован",
                Message = notificationMsg,
                Type = "info",
                CreatedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();

            string message;
            if (diff > 0)
                message = $"Выезд зарегистрирован. Стоимость: {finalPrice:F2} руб. Доплата: {diff:F2} руб.";
            else if (diff < 0)
                message = $"Выезд зарегистрирован. Стоимость: {finalPrice:F2} руб. Возврат: {Math.Abs(diff):F2} руб.";
            else
                message = $"Выезд зарегистрирован. Стоимость: {finalPrice:F2} руб.";

            return (true, message, finalPrice);
        }

        // Активные сессии
        public async Task<List<ParkingSession>> GetActiveSessionsAsync()
        {
            return await _context.ParkingSessions
                .Include(s => s.Spot)
                .Include(s => s.Reservation)
                    .ThenInclude(r => r!.Car)
                .Include(s => s.Reservation)
                    .ThenInclude(r => r!.User)
                .Where(s => s.ExitTime == null)
                .OrderBy(s => s.EntryTime)
                .ToListAsync();
        }

        // Логи оператора
        public async Task<List<Log>> GetOperatorLogsAsync(int operatorId, int limit = 200)
        {
            return await _context.Logs
                .Where(l => l.UserId == operatorId)
                .OrderByDescending(l => l.CreatedAt)
                .Take(limit)
                .ToListAsync();
        }
    }
}