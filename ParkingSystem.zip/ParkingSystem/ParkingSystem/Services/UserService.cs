﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class UserService
    {
        private readonly ApplicationDbContext _context;

        public UserService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User?> GetByIdAsync(int id)
        {
            return await _context.Users
                .Include(u => u.Status)
                .FirstOrDefaultAsync(u => u.Id == id);
        }

        public async Task<List<Car>> GetCarsAsync(int userId)
        {
            return await _context.Cars
                .Where(c => c.UserId == userId)
                .OrderBy(c => c.LicensePlate)
                .ToListAsync();
        }

        public async Task<List<Reservation>> GetReservationsAsync(int userId)
        {
            return await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
        }

        // Обновление профиля
        public async Task<bool> UpdateProfileAsync(int userId, string? lastName, string? firstName, string? middleName, string? phone, string? photoPath = null)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.LastName = lastName;
            user.FirstName = firstName;
            user.MiddleName = middleName;
            user.Phone = phone;
            if (photoPath != null)
                user.PhotoPath = photoPath;

            await _context.SaveChangesAsync();
            return true;
        }

        // Смена пароля
        public async Task<(bool success, string message)> ChangePasswordAsync(int userId, string currentPassword, string newPassword)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return (false, "Пользователь не найден");

            if (!PasswordHasher.Verify(currentPassword, user.PasswordHash))
                return (false, "Текущий пароль неверен");

            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
                return (false, "Новый пароль должен быть не менее 6 символов");

            user.PasswordHash = PasswordHasher.Hash(newPassword);
            await _context.SaveChangesAsync();
            return (true, "Пароль успешно изменён");
        }
    }
}