﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class UserProfileService
    {
        private readonly ApplicationDbContext _context;

        public UserProfileService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User?> GetProfileAsync(int userId)
        {
            return await _context.Users
                .Include(u => u.Status)
                .Include(u => u.Cars)
                .FirstOrDefaultAsync(u => u.Id == userId);
        }

        public async Task<List<Reservation>> GetUserReservationsAsync(int userId)
        {
            return await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt)
                .Take(20)
                .ToListAsync();
        }

        // Маскировка паспорта для оператора
        public static string MaskPassport(string? series, string? number)
        {
            if (string.IsNullOrEmpty(series) && string.IsNullOrEmpty(number))
                return "—";

            var maskedSeries = string.IsNullOrEmpty(series) ? "****" :
                (series.Length >= 4 ? $"{series.Substring(0, 2)}**" : series);

            var maskedNumber = string.IsNullOrEmpty(number) ? "******" :
                (number.Length >= 6 ? $"{number.Substring(0, 2)}**{number.Substring(4)}" : number);

            return $"{maskedSeries} {maskedNumber}";
        }

        // Полный паспорт для админа
        public static string FullPassport(string? series, string? number)
        {
            if (string.IsNullOrEmpty(series) && string.IsNullOrEmpty(number))
                return "—";

            return $"{series ?? "****"} {number ?? "******"}";
        }

        // ФИО
        public static string GetFullName(User user)
        {
            var parts = new[] { user.LastName, user.FirstName, user.MiddleName }
                .Where(p => !string.IsNullOrWhiteSpace(p));
            return parts.Any() ? string.Join(" ", parts) : user.Email;
        }
    }
}