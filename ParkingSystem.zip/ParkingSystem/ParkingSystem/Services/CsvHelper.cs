﻿using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace ParkingSystem.Services
{
    public static class CsvHelper
    {
        public static string Escape(string? value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            var v = value.Replace("\"", "\"\"");
            if (v.Contains(";") || v.Contains("\n") || v.Contains("\""))
                v = $"\"{v}\"";
            return v;
        }

        public static string BuildRow(params string?[] values)
        {
            return string.Join(";", values.Select(Escape));
        }

        public static byte[] BuildFile(IEnumerable<string> lines)
        {
            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            foreach (var line in lines)
            {
                sb.AppendLine(line);
            }
            return Encoding.UTF8.GetBytes(sb.ToString());
        }

        public static FileContentResult ToFile(IEnumerable<string> lines, string fileName)
        {
            var bytes = BuildFile(lines);
            return new FileContentResult(bytes, "text/csv")
            {
                FileDownloadName = fileName
            };
        }
    }
}