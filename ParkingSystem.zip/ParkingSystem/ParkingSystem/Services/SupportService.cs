﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class SupportService
    {
        private readonly ApplicationDbContext _context;

        public SupportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<SupportTicket> CreateAsync(int userId, string subject, string message)
        {
            var ticket = new SupportTicket
            {
                UserId = userId,
                Subject = subject,
                Message = message,
                CreatedAt = DateTime.UtcNow,
                Status = "Открыт"
            };

            _context.SupportTickets.Add(ticket);
            await _context.SaveChangesAsync();
            return ticket;
        }

        public async Task<List<SupportTicket>> GetUserTicketsAsync(int userId)
        {
            return await _context.SupportTickets
                .Where(t => t.UserId == userId)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();
        }

        public async Task<List<SupportTicket>> GetAllTicketsAsync()
        {
            return await _context.SupportTickets
                .Include(t => t.User)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();
        }

        public async Task<SupportTicket?> GetByIdAsync(int id)
        {
            return await _context.SupportTickets
                .Include(t => t.User)
                .FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task<bool> ReplyAsync(int ticketId, int adminId, string reply)
        {
            var ticket = await _context.SupportTickets.FindAsync(ticketId);
            if (ticket == null) return false;

            ticket.AdminReply = reply;
            ticket.RepliedAt = DateTime.UtcNow;
            ticket.RepliedByUserId = adminId;
            ticket.Status = "Отвечен";

            await _context.SaveChangesAsync();

            // Уведомление пользователю
            _context.Notifications.Add(new Notification
            {
                UserId = ticket.UserId,
                Title = $"Ответ по обращению №{ticket.Id}",
                Message = reply.Length > 150 ? reply.Substring(0, 150) + "..." : reply,
                Type = "info",
                CreatedAt = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> CloseAsync(int ticketId)
        {
            var ticket = await _context.SupportTickets.FindAsync(ticketId);
            if (ticket == null) return false;

            ticket.Status = "Закрыт";
            await _context.SaveChangesAsync();
            return true;
        }
    }
}