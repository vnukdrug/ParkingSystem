﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class AuthService
    {
        private readonly ApplicationDbContext _context;

        public AuthService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User?> LoginAsync(string email, string password)
        {
            var user = await _context.Users
                .Include(u => u.Status)
                .FirstOrDefaultAsync(u => u.Email == email);

            if (user == null) return null;
            if (!user.IsActive) return null;
            if (!PasswordHasher.Verify(password, user.PasswordHash)) return null;

            return user;
        }

        public async Task<User> RegisterAsync(
            string email,
            string password,
            string? lastName = null,
            string? firstName = null,
            string? middleName = null,
            string? passportSeries = null,
            string? passportNumber = null,
            string? phone = null,
            string? photoPath = null)
        {
            var user = new User
            {
                Email = email,
                PasswordHash = PasswordHasher.Hash(password),
                Role = "Пользователь",
                LastName = lastName,
                FirstName = firstName,
                MiddleName = middleName,
                PassportSeries = passportSeries,
                PassportNumber = passportNumber,
                Phone = phone,
                PhotoPath = photoPath,
                Balance = 0,
                ReservationsCount = 0,
                StatusId = 1,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<bool> EmailExistsAsync(string email)
        {
            return await _context.Users.AnyAsync(u => u.Email == email);
        }
    }
}