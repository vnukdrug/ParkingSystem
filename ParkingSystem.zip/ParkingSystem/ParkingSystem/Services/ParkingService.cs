﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class ParkingService
    {
        private readonly ApplicationDbContext _context;

        public ParkingService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<ParkingSpot>> GetParkingMapAsync()
        {
            return await _context.ParkingSpots
                .Include(s => s.Type)
                .OrderBy(s => s.Row)
                .ThenBy(s => s.Column)
                .ToListAsync();
        }

        public async Task<ParkingSpot?> GetSpotByIdAsync(int id)
        {
            return await _context.ParkingSpots
                .Include(s => s.Type)
                .FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<(int free, int occupied, int reserved, int maintenance)> GetStatsAsync()
        {
            var spots = await _context.ParkingSpots.ToListAsync();

            return (
                spots.Count(s => s.Status == SpotStatus.Free),
                spots.Count(s => s.Status == SpotStatus.Occupied),
                spots.Count(s => s.Status == SpotStatus.Reserved),
                spots.Count(s => s.Status == SpotStatus.Maintenance)
            );
        }

        public async Task<bool> UpdateStatusAsync(int spotId, SpotStatus status)
        {
            var spot = await _context.ParkingSpots.FindAsync(spotId);
            if (spot == null) return false;

            spot.Status = status;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Tariff?> GetActiveTariffAsync()
        {
            return await _context.Tariffs.FirstOrDefaultAsync(t => t.IsActive);
        }

        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _context.Users
                .Include(u => u.Status)
                .FirstOrDefaultAsync(u => u.Id == id);
        }

        // Для AJAX-обновления карты
        public async Task<List<object>> GetParkingMapForAjaxAsync()
        {
            var spots = await _context.ParkingSpots
                .Include(s => s.Type)
                .OrderBy(s => s.Row)
                .ThenBy(s => s.Column)
                .ToListAsync();

            return spots.Select(s => (object)new
            {
                s.Id,
                s.Number,
                Status = s.Status.ToString(),
                s.TypeId,
                TypeName = s.Type?.Name,
                s.Row,
                s.Column
            }).ToList();
        }
    }
}