﻿using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;

namespace ParkingSystem.Services
{
    public class AdminService
    {
        private readonly ApplicationDbContext _context;

        public AdminService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ============ ПОЛЬЗОВАТЕЛИ ============
        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _context.Users
                .Include(u => u.Status)
                .OrderBy(u => u.Id)
                .ToListAsync();
        }

        public async Task<bool> UpdateUserBalanceAsync(int userId, decimal newBalance)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            var diff = newBalance - user.Balance;
            user.Balance = newBalance;

            _context.Payments.Add(new Payment
            {
                UserId = userId,
                Amount = Math.Abs(diff),
                Type = diff >= 0 ? PaymentType.TopUp : PaymentType.Charge,
                CreatedAt = DateTime.UtcNow,
                Description = $"Изменение баланса администратором ({(diff >= 0 ? "+" : "")}{diff:F2})"
            });

            await _context.SaveChangesAsync();

            _context.Notifications.Add(new Notification
            {
                UserId = userId,
                Title = "Баланс изменён",
                Message = $"Администратор изменил ваш баланс. Новое значение: {newBalance:F2} ₽.",
                Type = "info",
                CreatedAt = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateUserRoleAsync(int userId, string newRole)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.Role = newRole;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<(bool success, string message)> CreateUserAsync(
            string email,
            string password,
            string role,
            string? lastName,
            string? firstName,
            string? middleName,
            string? phone,
            string? passportSeries,
            string? passportNumber,
            decimal balance)
        {
            if (await _context.Users.AnyAsync(u => u.Email == email))
                return (false, "Пользователь с таким логином уже существует");

            var user = new User
            {
                Email = email,
                PasswordHash = PasswordHasher.Hash(password),
                Role = role,
                LastName = lastName,
                FirstName = firstName,
                MiddleName = middleName,
                Phone = phone,
                PassportSeries = passportSeries,
                PassportNumber = passportNumber,
                Balance = balance,
                ReservationsCount = 0,
                StatusId = 1,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return (true, "Пользователь создан");
        }

        public async Task<bool> ToggleActiveAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.IsActive = !user.IsActive;
            await _context.SaveChangesAsync();

            if (user.IsActive)
            {
                _context.Notifications.Add(new Notification
                {
                    UserId = userId,
                    Title = "Аккаунт разблокирован",
                    Message = "Ваш аккаунт снова активен. Добро пожаловать!",
                    Type = "success",
                    CreatedAt = DateTime.UtcNow
                });
                await _context.SaveChangesAsync();
            }

            return true;
        }

        // ============ МЕСТА ============
        public async Task<List<ParkingSpot>> GetAllSpotsAsync()
        {
            return await _context.ParkingSpots
                .Include(s => s.Type)
                .OrderBy(s => s.Row)
                .ThenBy(s => s.Column)
                .ToListAsync();
        }

        public async Task<bool> UpdateSpotStatusAsync(int spotId, SpotStatus status)
        {
            var spot = await _context.ParkingSpots.FindAsync(spotId);
            if (spot == null) return false;

            spot.Status = status;
            await _context.SaveChangesAsync();
            return true;
        }

        // ============ ТАРИФЫ ============
        public async Task<List<Tariff>> GetAllTariffsAsync()
        {
            return await _context.Tariffs.OrderBy(t => t.Id).ToListAsync();
        }

        public async Task<bool> UpdateTariffAsync(int tariffId, string name, decimal pricePerHour, bool isActive)
        {
            var tariff = await _context.Tariffs.FindAsync(tariffId);
            if (tariff == null) return false;

            tariff.Name = name;
            tariff.PricePerHour = pricePerHour;
            tariff.IsActive = isActive;

            await _context.SaveChangesAsync();
            return true;
        }

        // ============ ЛОГИ ============
        public async Task<List<Log>> GetLogsAsync(int limit = 200)
        {
            var query = _context.Logs
                .Include(l => l.User)
                .OrderByDescending(l => l.CreatedAt)
                .AsQueryable();

            if (limit != int.MaxValue)
                query = query.Take(limit);

            return await query.ToListAsync();
        }

        public async Task<(List<Log> items, int totalCount)> GetLogsFilteredAsync(
            int page,
            int perPage,
            int? userId = null,
            string? action = null,
            DateTime? dateFrom = null,
            DateTime? dateTo = null,
            string? search = null)
        {
            var query = _context.Logs
                .Include(l => l.User)
                .AsQueryable();

            if (userId.HasValue)
                query = query.Where(l => l.UserId == userId.Value);

            if (!string.IsNullOrEmpty(action))
                query = query.Where(l => l.Action == action);

            if (dateFrom.HasValue)
                query = query.Where(l => l.CreatedAt >= dateFrom.Value);

            if (dateTo.HasValue)
                query = query.Where(l => l.CreatedAt <= dateTo.Value.AddDays(1));

            if (!string.IsNullOrEmpty(search))
                query = query.Where(l => l.Details != null && l.Details.Contains(search));

            query = query.OrderByDescending(l => l.CreatedAt);

            var total = await query.CountAsync();
            var items = await query
                .Skip((page - 1) * perPage)
                .Take(perPage)
                .ToListAsync();

            return (items, total);
        }

        public async Task<List<string>> GetDistinctActionsAsync()
        {
            return await _context.Logs
                .Select(l => l.Action)
                .Distinct()
                .OrderBy(a => a)
                .ToListAsync();
        }

        // ============ ОТЧЁТЫ ============
        public async Task<decimal> GetTotalRevenueAsync()
        {
            return await _context.Payments
                .Where(p => p.Type == PaymentType.Charge)
                .SumAsync(p => (decimal?)p.Amount) ?? 0;
        }

        public async Task<int> GetTotalReservationsAsync()
        {
            return await _context.Reservations.CountAsync();
        }

        // ============ ДАШБОРД ============
        public async Task<List<(DateTime date, decimal revenue)>> GetRevenueByDayAsync(int days = 14)
        {
            var fromDate = DateTime.UtcNow.Date.AddDays(-days + 1);

            var payments = await _context.Payments
                .Where(p => p.Type == PaymentType.Charge && p.CreatedAt >= fromDate)
                .ToListAsync();

            var grouped = payments
                .GroupBy(p => p.CreatedAt.Date)
                .Select(g => (date: g.Key, revenue: g.Sum(p => p.Amount)))
                .ToList();

            var result = new List<(DateTime, decimal)>();
            for (int i = 0; i < days; i++)
            {
                var day = fromDate.AddDays(i);
                var found = grouped.FirstOrDefault(g => g.date == day);
                result.Add((day, found.revenue));
            }

            return result;
        }

        public async Task<List<(int hour, int count)>> GetParkingLoadByHourAsync()
        {
            var fromDate = DateTime.UtcNow.Date.AddDays(-7);

            var sessions = await _context.ParkingSessions
                .Where(s => s.EntryTime >= fromDate)
                .ToListAsync();

            var result = new List<(int, int)>();
            for (int h = 0; h < 24; h++)
            {
                var count = sessions.Count(s => s.EntryTime.Hour == h);
                result.Add((h, count));
            }

            return result;
        }

        public async Task<List<(string userName, int count)>> GetTopUsersAsync(int top = 5)
        {
            var users = await _context.Users
                .OrderByDescending(u => u.ReservationsCount)
                .Take(top)
                .ToListAsync();

            return users
                .Select(u =>
                {
                    var fullName = $"{u.LastName} {u.FirstName}".Trim();
                    return (string.IsNullOrEmpty(fullName) ? u.Email : fullName, u.ReservationsCount);
                })
                .ToList();
        }

        public async Task<List<(string statusName, int count)>> GetUsersByStatusAsync()
        {
            var statuses = await _context.UserStatuses.ToListAsync();
            var result = new List<(string, int)>();

            foreach (var s in statuses)
            {
                var count = await _context.Users.CountAsync(u => u.StatusId == s.Id);
                result.Add((s.Name, count));
            }

            return result;
        }

        // ============ АНАЛИТИКА ОТМЕН ============
        public async Task<List<(string reason, int count)>> GetCancelReasonsAsync()
        {
            var cancelled = await _context.Reservations
                .Where(r => r.Status == ReservationStatus.Cancelled && !string.IsNullOrEmpty(r.CancelReason))
                .ToListAsync();

            return cancelled
                .GroupBy(r => r.CancelReason!)
                .Select(g => (reason: g.Key, count: g.Count()))
                .OrderByDescending(x => x.count)
                .Take(10)
                .ToList();
        }

        public async Task<(int total, int cancelled, decimal percent)> GetCancelStatsAsync()
        {
            var total = await _context.Reservations.CountAsync();
            var cancelled = await _context.Reservations.CountAsync(r => r.Status == ReservationStatus.Cancelled);
            var percent = total > 0 ? (decimal)cancelled / total * 100 : 0;
            return (total, cancelled, Math.Round(percent, 2));
        }

        public async Task<List<Reservation>> GetRecentCancellationsAsync(int limit = 20)
        {
            return await _context.Reservations
                .Include(r => r.User)
                .Include(r => r.Spot)
                .Where(r => r.Status == ReservationStatus.Cancelled)
                .OrderByDescending(r => r.CreatedAt)
                .Take(limit)
                .ToListAsync();
        }

        // ============ ТЕПЛОВАЯ КАРТА ============
        public async Task<List<(int spotId, int spotNumber, int count)>> GetSpotUsageHeatmapAsync()
        {
            var reservations = await _context.Reservations
                .Where(r => r.Status != ReservationStatus.Cancelled)
                .ToListAsync();

            var spots = await _context.ParkingSpots
                .OrderBy(s => s.Row)
                .ThenBy(s => s.Column)
                .ToListAsync();

            var grouped = reservations
                .GroupBy(r => r.SpotId)
                .ToDictionary(g => g.Key, g => g.Count());

            return spots
                .Select(s => (s.Id, s.Number, grouped.TryGetValue(s.Id, out var c) ? c : 0))
                .ToList();
        }
    }
}