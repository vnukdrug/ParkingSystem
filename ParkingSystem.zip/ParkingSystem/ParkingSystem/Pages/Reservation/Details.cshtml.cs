using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ParkingSystem.Data;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Reservation
{
    public class DetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly QrService _qrService;

        public DetailsModel(ApplicationDbContext context, QrService qrService)
        {
            _context = context;
            _qrService = qrService;
        }

        public Models.Reservation? Reservation { get; set; }
        public string QrText { get; set; } = string.Empty;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            var userRole = HttpContext.Session.GetString("UserRole");

            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            Reservation = await _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (Reservation == null)
                return NotFound();

            if (Reservation.UserId != userId.Value && userRole != "��������" && userRole != "�������������")
                return RedirectToPage("/Account/Login");

            QrText = _qrService.BuildReservationQrText(
                Reservation.Id,
                Reservation.Car?.LicensePlate ?? "�",
                Reservation.Spot?.Number ?? 0);

            return Page();
        }

        public IActionResult OnGetQrImage(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return Unauthorized();

            var reservation = _context.Reservations
                .Include(r => r.Spot)
                .Include(r => r.Car)
                .FirstOrDefault(r => r.Id == id);

            if (reservation == null)
                return NotFound();

            var text = _qrService.BuildReservationQrText(
                reservation.Id,
                reservation.Car?.LicensePlate ?? "�",
                reservation.Spot?.Number ?? 0);

            var png = _qrService.GenerateQr(text);
            return File(png, "image/png");
        }
    }
}