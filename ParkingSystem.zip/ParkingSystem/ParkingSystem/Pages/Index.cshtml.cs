using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Services;

namespace ParkingSystem.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ParkingService _parkingService;
        private readonly StatsService _statsService;

        public IndexModel(ParkingService parkingService, StatsService statsService)
        {
            _parkingService = parkingService;
            _statsService = statsService;
        }

        public int FreeCount { get; set; }
        public int OccupiedCount { get; set; }
        public int ReservedCount { get; set; }
        public int TotalCount { get; set; }
        public bool IsLoggedIn { get; set; }
        public string? UserRole { get; set; }
        public string? UserName { get; set; }

        // ��������� ����������
        public int TodayEntries { get; set; }
        public int TodayCompleted { get; set; }
        public double TodayLoadPercent { get; set; }
        public decimal TodayRevenue { get; set; }
        public int TotalUsersCount { get; set; }

        public async Task OnGetAsync()
        {
            var stats = await _parkingService.GetStatsAsync();
            FreeCount = stats.free;
            OccupiedCount = stats.occupied;
            ReservedCount = stats.reserved;
            TotalCount = FreeCount + OccupiedCount + ReservedCount + stats.maintenance;

            var userId = HttpContext.Session.GetInt32("UserId");
            UserRole = HttpContext.Session.GetString("UserRole");
            UserName = HttpContext.Session.GetString("UserEmail");
            IsLoggedIn = userId.HasValue;

            var publicStats = await _statsService.GetPublicStatsAsync();
            TodayEntries = publicStats.todayEntries;
            TodayCompleted = publicStats.todayCompleted;
            TodayLoadPercent = publicStats.todayLoadPercent;
            TodayRevenue = publicStats.todayRevenue;
            TotalUsersCount = publicStats.totalUsers;
        }
    }
}