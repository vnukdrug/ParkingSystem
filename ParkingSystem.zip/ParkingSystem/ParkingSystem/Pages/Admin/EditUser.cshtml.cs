using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Admin
{
    public class EditUserModel : PageModel
    {
        private readonly UserProfileService _profileService;
        private readonly AdminService _adminService;
        private readonly LogService _logService;

        public EditUserModel(
            UserProfileService profileService,
            AdminService adminService,
            LogService logService)
        {
            _profileService = profileService;
            _adminService = adminService;
            _logService = logService;
        }

        public User? ProfileUser { get; set; }

        [BindProperty]
        public string? LastName { get; set; }

        [BindProperty]
        public string? FirstName { get; set; }

        [BindProperty]
        public string? MiddleName { get; set; }

        [BindProperty]
        public string? Phone { get; set; }

        [BindProperty]
        public string? PassportSeries { get; set; }

        [BindProperty]
        public string? PassportNumber { get; set; }

        [BindProperty]
        public decimal Balance { get; set; }

        [BindProperty]
        public string Role { get; set; } = "������������";

        [BindProperty]
        public bool IsActive { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return RedirectToPage("/Account/Login");

            ProfileUser = await _profileService.GetProfileAsync(id);
            if (ProfileUser == null)
                return NotFound();

            LastName = ProfileUser.LastName;
            FirstName = ProfileUser.FirstName;
            MiddleName = ProfileUser.MiddleName;
            Phone = ProfileUser.Phone;
            PassportSeries = ProfileUser.PassportSeries;
            PassportNumber = ProfileUser.PassportNumber;
            Balance = ProfileUser.Balance;
            Role = ProfileUser.Role;
            IsActive = ProfileUser.IsActive;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var adminRole = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (adminRole != "�������������" || !adminId.HasValue)
                return RedirectToPage("/Account/Login");

            var user = await _profileService.GetProfileAsync(id);
            if (user == null)
                return NotFound();

            user.LastName = LastName;
            user.FirstName = FirstName;
            user.MiddleName = MiddleName;
            user.Phone = Phone;
            user.PassportSeries = PassportSeries;
            user.PassportNumber = PassportNumber;
            user.Role = Role;
            user.IsActive = IsActive;

            var diff = Balance - user.Balance;
            if (diff != 0)
            {
                user.Balance = Balance;
            }

            var context = HttpContext.RequestServices.GetRequiredService<Data.ApplicationDbContext>();
            await context.SaveChangesAsync();

            await _logService.LogAsync(adminId.Value, "�������������� ������������",
                $"ID {id}: ���={LastName} {FirstName}, ����={Role}, IsActive={IsActive}");

            return RedirectToPage("/UserProfile/View", new { id });
        }
    }
}