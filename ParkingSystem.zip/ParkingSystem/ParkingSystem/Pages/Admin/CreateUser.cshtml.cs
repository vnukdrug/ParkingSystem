using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Services;
using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Pages.Admin
{
    public class CreateUserModel : PageModel
    {
        private readonly AdminService _adminService;
        private readonly LogService _logService;

        public CreateUserModel(AdminService adminService, LogService logService)
        {
            _adminService = adminService;
            _logService = logService;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required(ErrorMessage = "������� �����")]
            [StringLength(50, MinimumLength = 3)]
            public string Email { get; set; } = string.Empty;

            [Required(ErrorMessage = "������� ������")]
            [StringLength(100, MinimumLength = 1)]
            [DataType(DataType.Password)]
            public string Password { get; set; } = string.Empty;

            [Required(ErrorMessage = "�������� ����")]
            public string Role { get; set; } = "������������";

            [MaxLength(50)]
            public string? LastName { get; set; }

            [MaxLength(50)]
            public string? FirstName { get; set; }

            [MaxLength(50)]
            public string? MiddleName { get; set; }

            [MaxLength(20)]
            public string? Phone { get; set; }

            [StringLength(4, MinimumLength = 4, ErrorMessage = "����� � 4 �����")]
            public string? PassportSeries { get; set; }

            [StringLength(6, MinimumLength = 6, ErrorMessage = "����� � 6 ����")]
            public string? PassportNumber { get; set; }

            public decimal Balance { get; set; }
        }

        public IActionResult OnGet()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return RedirectToPage("/Account/Login");

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var adminRole = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (adminRole != "�������������" || !adminId.HasValue)
                return RedirectToPage("/Account/Login");

            if (!ModelState.IsValid) return Page();

            var result = await _adminService.CreateUserAsync(
                Input.Email,
                Input.Password,
                Input.Role,
                Input.LastName,
                Input.FirstName,
                Input.MiddleName,
                Input.Phone,
                Input.PassportSeries,
                Input.PassportNumber,
                Input.Balance);

            if (!result.success)
            {
                ModelState.AddModelError(string.Empty, result.message);
                return Page();
            }

            await _logService.LogAsync(adminId.Value, "�������� ������������",
                $"�����: {Input.Email}, ����: {Input.Role}");

            return RedirectToPage("/Admin/Index");
        }
    }
}