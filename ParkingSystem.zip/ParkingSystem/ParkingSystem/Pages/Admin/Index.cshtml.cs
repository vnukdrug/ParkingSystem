using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Admin
{
    public class IndexModel : PageModel
    {
        private readonly AdminService _adminService;
        private readonly LogService _logService;

        public IndexModel(AdminService adminService, LogService logService)
        {
            _adminService = adminService;
            _logService = logService;
        }

        public decimal TotalRevenue { get; set; }
        public int TotalReservations { get; set; }
        public int TotalUsers { get; set; }
        public int TotalSpots { get; set; }

        public IActionResult OnGet()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return RedirectToPage("/Account/Login");

            return Page();
        }

        public async Task<IActionResult> OnGetDataAsync(
            int logsPage = 1,
            int logsPerPage = 15,
            int? logsUserId = null,
            string? logsAction = null,
            DateTime? logsFrom = null,
            DateTime? logsTo = null,
            string? logsSearch = null)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return new JsonResult(new { success = false });

            var users = await _adminService.GetAllUsersAsync();
            var spots = await _adminService.GetAllSpotsAsync();
            var tariffs = await _adminService.GetAllTariffsAsync();

            var (pagedLogs, totalLogs) = await _adminService.GetLogsFilteredAsync(
                logsPage, logsPerPage, logsUserId, logsAction, logsFrom, logsTo, logsSearch);

            var totalPages = (int)Math.Ceiling((double)totalLogs / logsPerPage);
            if (totalPages < 1) totalPages = 1;
            if (logsPage < 1) logsPage = 1;
            if (logsPage > totalPages) logsPage = totalPages;

            var distinctActions = await _adminService.GetDistinctActionsAsync();

            TotalRevenue = await _adminService.GetTotalRevenueAsync();
            TotalReservations = await _adminService.GetTotalReservationsAsync();
            TotalUsers = users.Count;
            TotalSpots = spots.Count;

            return new JsonResult(new
            {
                success = true,
                stats = new
                {
                    totalRevenue = TotalRevenue,
                    totalReservations = TotalReservations,
                    totalUsers = TotalUsers,
                    totalSpots = TotalSpots
                },
                users = users.Select(u => new
                {
                    u.Id,
                    u.Email,
                    FullName = $"{u.LastName} {u.FirstName} {u.MiddleName}".Trim(),
                    u.Role,
                    u.Balance,
                    u.ReservationsCount,
                    StatusName = u.Status?.Name,
                    Discount = u.Status?.DiscountPercent ?? 0,
                    IsActive = u.IsActive,
                    CreatedAt = u.CreatedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm")
                }),
                spots = spots.Select(s => new
                {
                    s.Id,
                    s.Number,
                    s.Row,
                    s.Column,
                    Status = s.Status.ToString(),
                    TypeName = s.Type?.Name
                }),
                tariffs = tariffs.Select(t => new
                {
                    t.Id,
                    t.Name,
                    t.PricePerHour,
                    t.IsActive
                }),
                logs = pagedLogs.Select(l => new
                {
                    l.Id,
                    UserId = l.UserId,
                    UserEmail = l.User?.Email ?? "�",
                    l.Action,
                    l.Details,
                    l.IpAddress,
                    CreatedAt = l.CreatedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss")
                }),
                logsPagination = new
                {
                    currentPage = logsPage,
                    perPage = logsPerPage,
                    totalItems = totalLogs,
                    totalPages = totalPages
                },
                distinctActions = distinctActions
            });
        }

        public async Task<IActionResult> OnGetDashboardAsync()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return new JsonResult(new { success = false });

            var revenueByDay = await _adminService.GetRevenueByDayAsync(14);
            var loadByHour = await _adminService.GetParkingLoadByHourAsync();
            var topUsers = await _adminService.GetTopUsersAsync(5);
            var usersByStatus = await _adminService.GetUsersByStatusAsync();
            var cancelReasons = await _adminService.GetCancelReasonsAsync();
            var cancelStats = await _adminService.GetCancelStatsAsync();
            var heatmap = await _adminService.GetSpotUsageHeatmapAsync();

            return new JsonResult(new
            {
                success = true,
                revenueByDay = revenueByDay.Select(x => new
                {
                    date = x.date.ToString("dd.MM"),
                    revenue = x.revenue
                }),
                loadByHour = loadByHour.Select(x => new
                {
                    hour = $"{x.hour}:00",
                    count = x.count
                }),
                topUsers = topUsers.Select(x => new
                {
                    name = x.userName,
                    count = x.count
                }),
                usersByStatus = usersByStatus.Select(x => new
                {
                    status = x.statusName,
                    count = x.count
                }),
                cancelReasons = cancelReasons.Select(x => new
                {
                    reason = x.reason,
                    count = x.count
                }),
                cancelStats = new
                {
                    total = cancelStats.total,
                    cancelled = cancelStats.cancelled,
                    percent = cancelStats.percent
                },
                heatmap = heatmap.Select(x => new
                {
                    spotId = x.spotId,
                    spotNumber = x.spotNumber,
                    count = x.count
                })
            });
        }

        public async Task<IActionResult> OnGetExportLogsAsync(
            int? logsUserId = null,
            string? logsAction = null,
            DateTime? logsFrom = null,
            DateTime? logsTo = null,
            string? logsSearch = null)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return RedirectToPage("/Account/Login");

            var (logs, _) = await _adminService.GetLogsFilteredAsync(
                1, int.MaxValue, logsUserId, logsAction, logsFrom, logsTo, logsSearch);

            var lines = new List<string>
            {
                CsvHelper.BuildRow("ID", "����", "������������", "��������", "������", "IP-�����")
            };

            foreach (var l in logs)
            {
                lines.Add(CsvHelper.BuildRow(
                    l.Id.ToString(),
                    l.CreatedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss"),
                    l.User?.Email ?? "�",
                    l.Action,
                    l.Details,
                    l.IpAddress));
            }

            var fileName = $"logs_{DateTime.Now:yyyy-MM-dd_HH-mm}.csv";
            return CsvHelper.ToFile(lines, fileName);
        }

        public async Task<IActionResult> OnGetExportUsersAsync()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "�������������")
                return RedirectToPage("/Account/Login");

            var users = await _adminService.GetAllUsersAsync();

            var lines = new List<string>
            {
                CsvHelper.BuildRow("ID", "�����", "�������", "���", "��������", "�������", "�������", "����", "������", "������", "������", "�������", "���� �����������")
            };

            foreach (var u in users)
            {
                lines.Add(CsvHelper.BuildRow(
                    u.Id.ToString(),
                    u.Email,
                    u.LastName,
                    u.FirstName,
                    u.MiddleName,
                    u.Phone,
                    $"{u.PassportSeries} {u.PassportNumber}",
                    u.Role,
                    u.Balance.ToString("F2"),
                    u.ReservationsCount.ToString(),
                    u.Status?.Name,
                    u.IsActive ? "��" : "���",
                    u.CreatedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm")));
            }

            var fileName = $"users_{DateTime.Now:yyyy-MM-dd_HH-mm}.csv";
            return CsvHelper.ToFile(lines, fileName);
        }

        public async Task<IActionResult> OnPostUpdateBalanceAsync([FromBody] UpdateBalanceRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (role != "�������������" || !adminId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var ok = await _adminService.UpdateUserBalanceAsync(req.UserId, req.NewBalance);
            if (ok)
            {
                await _logService.LogAsync(adminId.Value, "��������� �������",
                    $"������������ {req.UserId}, ����� ������ {req.NewBalance}");
            }

            return new JsonResult(new { success = ok });
        }

        public async Task<IActionResult> OnPostUpdateRoleAsync([FromBody] UpdateRoleRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (role != "�������������" || !adminId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var ok = await _adminService.UpdateUserRoleAsync(req.UserId, req.NewRole);
            if (ok)
            {
                await _logService.LogAsync(adminId.Value, "��������� ����",
                    $"������������ {req.UserId}, ����� ���� {req.NewRole}");
            }

            return new JsonResult(new { success = ok });
        }

        public async Task<IActionResult> OnPostUpdateSpotStatusAsync([FromBody] UpdateSpotRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (role != "�������������" || !adminId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            if (!Enum.TryParse<SpotStatus>(req.Status, out var status))
                return new JsonResult(new { success = false, message = "�������� ������" });

            var ok = await _adminService.UpdateSpotStatusAsync(req.SpotId, status);
            if (ok)
            {
                await _logService.LogAsync(adminId.Value, "��������� ������� �����",
                    $"����� {req.SpotId}, ������ {req.Status}");
            }

            return new JsonResult(new { success = ok });
        }

        public async Task<IActionResult> OnPostUpdateTariffAsync([FromBody] UpdateTariffRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (role != "�������������" || !adminId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var ok = await _adminService.UpdateTariffAsync(req.TariffId, req.Name, req.PricePerHour, req.IsActive);
            if (ok)
            {
                await _logService.LogAsync(adminId.Value, "��������� ������",
                    $"����� {req.TariffId}, ���� {req.PricePerHour}, ������� {req.IsActive}");
            }

            return new JsonResult(new { success = ok });
        }

        public async Task<IActionResult> OnPostToggleActiveAsync([FromBody] ToggleActiveRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var adminId = HttpContext.Session.GetInt32("UserId");
            if (role != "�������������" || !adminId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var ok = await _adminService.ToggleActiveAsync(req.UserId);
            if (ok)
            {
                await _logService.LogAsync(adminId.Value, "��������� ������� ������������",
                    $"������������ {req.UserId}");
            }

            return new JsonResult(new { success = ok });
        }
    }

    public class UpdateBalanceRequest
    {
        public int UserId { get; set; }
        public decimal NewBalance { get; set; }
    }

    public class UpdateRoleRequest
    {
        public int UserId { get; set; }
        public string NewRole { get; set; } = string.Empty;
    }

    public class UpdateSpotRequest
    {
        public int SpotId { get; set; }
        public string Status { get; set; } = string.Empty;
    }

    public class UpdateTariffRequest
    {
        public int TariffId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal PricePerHour { get; set; }
        public bool IsActive { get; set; }
    }

    public class ToggleActiveRequest
    {
        public int UserId { get; set; }
    }
}