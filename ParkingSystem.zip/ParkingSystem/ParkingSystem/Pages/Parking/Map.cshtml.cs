using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Parking
{
    public class MapModel : PageModel
    {
        private readonly ParkingService _parkingService;
        private readonly ReservationService _reservationService;
        private readonly CarService _carService;
        private readonly LogService _logService;

        public MapModel(
            ParkingService parkingService,
            ReservationService reservationService,
            CarService carService,
            LogService logService)
        {
            _parkingService = parkingService;
            _reservationService = reservationService;
            _carService = carService;
            _logService = logService;
        }

        public List<ParkingSpot> Spots { get; set; } = new();
        public int FreeCount { get; set; }
        public int OccupiedCount { get; set; }
        public int ReservedCount { get; set; }
        public int MaintenanceCount { get; set; }

        public int CurrentUserId { get; set; }
        public decimal CurrentBalance { get; set; }
        public List<Car> UserCars { get; set; } = new();

        public async Task OnGetAsync()
        {
            Spots = await _parkingService.GetParkingMapAsync();

            var stats = await _parkingService.GetStatsAsync();
            FreeCount = stats.free;
            OccupiedCount = stats.occupied;
            ReservedCount = stats.reserved;
            MaintenanceCount = stats.maintenance;

            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId.HasValue)
            {
                CurrentUserId = userId.Value;

                var user = await _parkingService.GetUserByIdAsync(userId.Value);
                if (user != null)
                {
                    CurrentBalance = user.Balance;
                }

                UserCars = await _carService.GetUserCarsAsync(userId.Value);
            }
        }

        // AJAX: ���������� �������� �����
        public async Task<IActionResult> OnGetRefreshAsync()
        {
            var spots = await _parkingService.GetParkingMapForAjaxAsync();
            var stats = await _parkingService.GetStatsAsync();

            return new JsonResult(new
            {
                success = true,
                spots = spots,
                stats = new
                {
                    free = stats.free,
                    occupied = stats.occupied,
                    reserved = stats.reserved,
                    maintenance = stats.maintenance
                }
            });
        }

        public async Task<IActionResult> OnGetReservationFormAsync(int spotId, DateTime start, DateTime end)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            var cars = await _carService.GetUserCarsAsync(userId.Value);

            decimal price = 0;
            if (end > start)
            {
                price = await _reservationService.CalculatePriceAsync(spotId, userId.Value, start, end);
            }

            return new JsonResult(new
            {
                success = true,
                cars = cars.Select(c => new { c.Id, c.LicensePlate, c.Brand, c.Model }),
                price
            });
        }

        public async Task<IActionResult> OnPostCreateAsync([FromBody] CreateReservationRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            var result = await _reservationService.CreateAsync(
                userId.Value, request.SpotId, request.CarId, request.Start, request.End);

            if (result.success)
            {
                await _logService.LogAsync(userId.Value, "�������� �����",
                    $"����� {request.SpotId}, ���������� {request.CarId}, � {request.Start} �� {request.End}, ����� {result.reservation?.TotalPrice}");
            }

            return new JsonResult(new
            {
                success = result.success,
                message = result.message,
                price = result.reservation?.TotalPrice
            });
        }

        public async Task<IActionResult> OnPostAddCarAsync([FromBody] AddCarRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            if (string.IsNullOrWhiteSpace(request.LicensePlate))
                return new JsonResult(new { success = false, message = "������� ��������" });

            var car = await _carService.AddCarAsync(userId.Value, request.LicensePlate, request.Brand, request.Model);

            await _logService.LogAsync(userId.Value, "���������� ����������", $"��������: {request.LicensePlate}");

            return new JsonResult(new
            {
                success = true,
                car = new { car.Id, car.LicensePlate, car.Brand, car.Model }
            });
        }
    }

    public class CreateReservationRequest
    {
        public int SpotId { get; set; }
        public int CarId { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }

    public class AddCarRequest
    {
        public string LicensePlate { get; set; } = string.Empty;
        public string? Brand { get; set; }
        public string? Model { get; set; }
    }
}