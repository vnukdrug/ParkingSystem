using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Notifications
{
    public class IndexModel : PageModel
    {
        private readonly NotificationService _notificationService;

        public IndexModel(NotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        public List<Notification> Notifications { get; set; } = new();

        public async Task<IActionResult> OnGetAsync()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            Notifications = await _notificationService.GetUserNotificationsAsync(userId.Value);
            return Page();
        }

        public async Task<IActionResult> OnPostMarkAllAsync()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            await _notificationService.MarkAllAsReadAsync(userId.Value);
            return RedirectToPage();
        }
    }
}