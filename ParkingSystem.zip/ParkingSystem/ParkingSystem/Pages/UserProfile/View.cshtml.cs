using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.UserProfile
{
    public class ViewModel : PageModel
    {
        private readonly UserProfileService _profileService;

        public ViewModel(UserProfileService profileService)
        {
            _profileService = profileService;
        }

        public User? ProfileUser { get; set; }
        public List<Models.Reservation> Reservations { get; set; } = new();
        public string MaskedPassport { get; set; } = "�";
        public string FullPassport { get; set; } = "�";
        public string FullName { get; set; } = "�";
        public bool CanEdit { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "��������" && role != "�������������")
                return RedirectToPage("/Account/Login");

            ProfileUser = await _profileService.GetProfileAsync(id);
            if (ProfileUser == null)
                return NotFound();

            Reservations = await _profileService.GetUserReservationsAsync(id);
            MaskedPassport = UserProfileService.MaskPassport(ProfileUser.PassportSeries, ProfileUser.PassportNumber);
            FullPassport = UserProfileService.FullPassport(ProfileUser.PassportSeries, ProfileUser.PassportNumber);
            FullName = UserProfileService.GetFullName(ProfileUser);
            CanEdit = role == "�������������";

            return Page();
        }
    }
}