using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Operator
{
    public class LogsModel : PageModel
    {
        private readonly OperatorService _operatorService;

        public LogsModel(OperatorService operatorService)
        {
            _operatorService = operatorService;
        }

        public List<Log> Logs { get; set; } = new();

        public async Task<IActionResult> OnGetAsync()
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");
            if ((role != "��������" && role != "�������������") || !userId.HasValue)
                return RedirectToPage("/Account/Login");

            Logs = await _operatorService.GetOperatorLogsAsync(userId.Value);
            return Page();
        }
    }
}