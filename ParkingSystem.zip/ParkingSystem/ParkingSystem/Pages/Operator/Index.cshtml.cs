using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Operator
{
    public class IndexModel : PageModel
    {
        private readonly OperatorService _operatorService;
        private readonly LogService _logService;

        public IndexModel(OperatorService operatorService, LogService logService)
        {
            _operatorService = operatorService;
            _logService = logService;
        }

        public List<Models.Reservation> ActiveReservations { get; set; } = new();
        public List<Models.ParkingSession> ActiveSessions { get; set; } = new();

        public IActionResult OnGet()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "��������" && role != "�������������")
                return RedirectToPage("/Account/Login");

            return Page();
        }

        public async Task<IActionResult> OnGetDataAsync()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "��������" && role != "�������������")
                return new JsonResult(new { success = false });

            ActiveReservations = await _operatorService.GetActiveReservationsAsync();
            ActiveSessions = await _operatorService.GetActiveSessionsAsync();

            return new JsonResult(new
            {
                success = true,
                reservations = ActiveReservations.Select(r => new
                {
                    r.Id,
                    UserId = r.UserId,
                    SpotNumber = r.Spot?.Number,
                    CarPlate = r.Car?.LicensePlate,
                    UserEmail = r.User?.Email,
                    StartTime = r.StartTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    EndTime = r.EndTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    Price = r.TotalPrice
                }),
                sessions = ActiveSessions.Select(s => new
                {
                    s.Id,
                    UserId = s.Reservation?.UserId,
                    SpotNumber = s.Spot?.Number,
                    CarPlate = s.Reservation?.Car?.LicensePlate,
                    EntryTime = s.EntryTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    ReservationId = s.ReservationId
                })
            });
        }

        // AJAX: ����� ����� �� QR
        public async Task<IActionResult> OnGetFindReservationAsync(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "��������" && role != "�������������")
                return new JsonResult(new { success = false, message = "������ ��������" });

            var reservation = await _operatorService.GetReservationByIdAsync(id);

            if (reservation == null)
                return new JsonResult(new { success = false, message = "����� �� �������" });

            if (reservation.Status != ReservationStatus.Active)
                return new JsonResult(new { success = false, message = "����� ���������" });

            return new JsonResult(new
            {
                success = true,
                reservation = new
                {
                    id = reservation.Id,
                    spotNumber = reservation.Spot?.Number ?? 0,
                    carPlate = reservation.Car?.LicensePlate ?? "�",
                    userEmail = reservation.User?.Email ?? "�",
                    startTime = reservation.StartTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    endTime = reservation.EndTime.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    price = reservation.TotalPrice,
                    status = reservation.Status.ToString()
                }
            });
        }

        public async Task<IActionResult> OnPostEntryAsync([FromBody] EntryRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");
            if ((role != "��������" && role != "�������������") || !userId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var result = await _operatorService.RegisterEntryAsync(req.ReservationId, userId.Value);
            if (result.success)
            {
                await _logService.LogAsync(userId.Value, "����������� ������",
                    $"����� {req.ReservationId}");
            }

            return new JsonResult(new { success = result.success, message = result.message });
        }

        public async Task<IActionResult> OnPostExitAsync([FromBody] ExitRequest req)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");
            if ((role != "��������" && role != "�������������") || !userId.HasValue)
                return new JsonResult(new { success = false, message = "������ ��������" });

            var result = await _operatorService.RegisterExitAsync(req.SessionId, userId.Value);
            if (result.success)
            {
                await _logService.LogAsync(userId.Value, "����������� ������",
                    $"������ {req.SessionId}, ����� {result.total}");
            }

            return new JsonResult(new
            {
                success = result.success,
                message = result.message,
                total = result.total
            });
        }
    }

    public class EntryRequest
    {
        public int ReservationId { get; set; }
    }

    public class ExitRequest
    {
        public int SessionId { get; set; }
    }
}