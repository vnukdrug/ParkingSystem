using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;
using System.ComponentModel.DataAnnotations;

namespace ParkingSystem.Pages.Profile
{
    public class EditModel : PageModel
    {
        private readonly UserService _userService;
        private readonly NotificationService _notificationService;
        private readonly LogService _logService;
        private readonly IWebHostEnvironment _env;

        public EditModel(
            UserService userService,
            NotificationService notificationService,
            LogService logService,
            IWebHostEnvironment env)
        {
            _userService = userService;
            _notificationService = notificationService;
            _logService = logService;
            _env = env;
        }

        public User? CurrentUser { get; set; }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        [BindProperty]
        public IFormFile? Photo { get; set; }

        public class InputModel
        {
            [Required(ErrorMessage = "������� �������")]
            [MaxLength(50)]
            public string LastName { get; set; } = string.Empty;

            [Required(ErrorMessage = "������� ���")]
            [MaxLength(50)]
            public string FirstName { get; set; } = string.Empty;

            [MaxLength(50)]
            public string? MiddleName { get; set; }

            [Required(ErrorMessage = "������� �������")]
            [MaxLength(20)]
            public string Phone { get; set; } = string.Empty;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            CurrentUser = await _userService.GetByIdAsync(userId.Value);
            if (CurrentUser == null)
                return RedirectToPage("/Account/Logout");

            Input.LastName = CurrentUser.LastName ?? "";
            Input.FirstName = CurrentUser.FirstName ?? "";
            Input.MiddleName = CurrentUser.MiddleName;
            Input.Phone = CurrentUser.Phone ?? "";

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            CurrentUser = await _userService.GetByIdAsync(userId.Value);
            if (CurrentUser == null)
                return RedirectToPage("/Account/Logout");

            if (!ModelState.IsValid)
                return Page();

            string? photoPath = null;
            if (Photo != null && Photo.Length > 0)
            {
                var allowedExt = new[] { ".jpg", ".jpeg", ".png" };
                var ext = Path.GetExtension(Photo.FileName).ToLowerInvariant();
                if (!allowedExt.Contains(ext))
                {
                    ModelState.AddModelError(string.Empty, "���� ������ ���� ������� JPG ��� PNG");
                    return Page();
                }

                var uploadsDir = Path.Combine(_env.WebRootPath, "uploads", "users");
                Directory.CreateDirectory(uploadsDir);

                var fileName = $"{Guid.NewGuid()}{ext}";
                var filePath = Path.Combine(uploadsDir, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await Photo.CopyToAsync(stream);
                }

                photoPath = $"/uploads/users/{fileName}";
            }

            await _userService.UpdateProfileAsync(
                userId.Value,
                Input.LastName,
                Input.FirstName,
                Input.MiddleName,
                Input.Phone,
                photoPath);

            await _logService.LogAsync(userId.Value, "�������������� �������", "�������� ������ ������");

            await _notificationService.CreateAsync(
                userId.Value,
                "������� �������",
                "���� ������ ������ ���� ������� ��������.",
                "success");

            return RedirectToPage("/Profile/Index");
        }
    }
}