using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ParkingSystem.Models;
using ParkingSystem.Services;

namespace ParkingSystem.Pages.Profile
{
    public class IndexModel : PageModel
    {
        private readonly UserService _userService;
        private readonly PaymentService _paymentService;
        private readonly CarService _carService;
        private readonly LogService _logService;
        private readonly ReservationService _reservationService;

        public IndexModel(
            UserService userService,
            PaymentService paymentService,
            CarService carService,
            LogService logService,
            ReservationService reservationService)
        {
            _userService = userService;
            _paymentService = paymentService;
            _carService = carService;
            _logService = logService;
            _reservationService = reservationService;
        }

        public User? CurrentUser { get; set; }
        public List<Models.Reservation> Reservations { get; set; } = new();
        public List<Payment> Payments { get; set; } = new();
        public List<Car> Cars { get; set; } = new();

        public int CurrentPaymentsPage { get; set; } = 1;
        public int TotalPaymentsPages { get; set; } = 1;
        public int PaymentsPerPage { get; set; } = 10;
        public int TotalPaymentsCount { get; set; }

        public string? PaymentsTypeFilter { get; set; }
        public DateTime? PaymentsDateFrom { get; set; }
        public DateTime? PaymentsDateTo { get; set; }

        public async Task<IActionResult> OnGetAsync(
            int paymentsPage = 1,
            string? paymentsType = null,
            DateTime? paymentsFrom = null,
            DateTime? paymentsTo = null)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            CurrentUser = await _userService.GetByIdAsync(userId.Value);
            if (CurrentUser == null)
                return RedirectToPage("/Account/Logout");

            Reservations = await _userService.GetReservationsAsync(userId.Value);
            Cars = await _userService.GetCarsAsync(userId.Value);

            CurrentPaymentsPage = paymentsPage < 1 ? 1 : paymentsPage;
            PaymentsTypeFilter = paymentsType;
            PaymentsDateFrom = paymentsFrom;
            PaymentsDateTo = paymentsTo;

            var (payments, total) = await _paymentService.GetUserPaymentsFilteredAsync(
                userId.Value,
                CurrentPaymentsPage,
                PaymentsPerPage,
                PaymentsTypeFilter,
                PaymentsDateFrom,
                PaymentsDateTo);

            Payments = payments;
            TotalPaymentsCount = total;
            TotalPaymentsPages = (int)Math.Ceiling((double)total / PaymentsPerPage);
            if (TotalPaymentsPages < 1) TotalPaymentsPages = 1;

            return Page();
        }

        // ============ ������� ============
        public async Task<IActionResult> OnGetExportPaymentsAsync(
            string? paymentsType = null,
            DateTime? paymentsFrom = null,
            DateTime? paymentsTo = null)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return RedirectToPage("/Account/Login");

            var (payments, _) = await _paymentService.GetUserPaymentsFilteredAsync(
                userId.Value, 1, int.MaxValue, paymentsType, paymentsFrom, paymentsTo);

            var lines = new List<string>
            {
                CsvHelper.BuildRow("ID", "����", "��������", "���", "�����")
            };

            foreach (var p in payments)
            {
                lines.Add(CsvHelper.BuildRow(
                    p.Id.ToString(),
                    p.CreatedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm"),
                    p.Description,
                    p.Type == PaymentType.TopUp ? "����������" : "��������",
                    p.Amount.ToString("F2")));
            }

            var fileName = $"payments_{DateTime.Now:yyyy-MM-dd_HH-mm}.csv";
            return CsvHelper.ToFile(lines, fileName);
        }

        // ============ AJAX ============
        public async Task<IActionResult> OnPostTopUpAsync([FromBody] TopUpRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            if (request.Amount <= 0)
                return new JsonResult(new { success = false, message = "������������ �����" });

            var ok = await _paymentService.TopUpBalanceAsync(userId.Value, request.Amount);
            if (ok)
            {
                await _logService.LogAsync(userId.Value, "���������� �������", $"�����: {request.Amount} ���.");
            }

            return new JsonResult(new { success = ok, message = ok ? "������ ��������" : "������ ����������" });
        }

        public async Task<IActionResult> OnPostAddCarAsync([FromBody] AddCarRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            if (string.IsNullOrWhiteSpace(request.LicensePlate))
                return new JsonResult(new { success = false, message = "������� ��������" });

            var car = await _carService.AddCarAsync(userId.Value, request.LicensePlate.Trim(), request.Brand, request.Model);
            await _logService.LogAsync(userId.Value, "���������� ����������", $"��������: {request.LicensePlate}");

            return new JsonResult(new
            {
                success = true,
                car = new { car.Id, car.LicensePlate, car.Brand, car.Model }
            });
        }

        public async Task<IActionResult> OnPostDeleteCarAsync([FromBody] DeleteCarRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            var ok = await _carService.DeleteCarAsync(request.CarId, userId.Value);
            if (ok)
            {
                await _logService.LogAsync(userId.Value, "�������� ����������", $"ID: {request.CarId}");
            }

            return new JsonResult(new { success = ok });
        }

        public async Task<IActionResult> OnPostCancelAsync([FromBody] CancelRequest request)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (!userId.HasValue)
                return new JsonResult(new { success = false, message = "�� �����������" });

            var result = await _reservationService.CancelAsync(request.ReservationId, userId.Value, request.Reason);

            if (result.success)
            {
                await _logService.LogAsync(userId.Value, "������ �����",
                    $"����� {request.ReservationId}, ������� {result.refund}, �������: {request.Reason}");
            }

            return new JsonResult(new
            {
                success = result.success,
                message = result.message,
                refund = result.refund
            });
        }

        // DTO
        public class TopUpRequest
        {
            public decimal Amount { get; set; }
        }

        public class AddCarRequest
        {
            public string LicensePlate { get; set; } = string.Empty;
            public string? Brand { get; set; }
            public string? Model { get; set; }
        }

        public class DeleteCarRequest
        {
            public int CarId { get; set; }
        }

        public class CancelRequest
        {
            public int ReservationId { get; set; }
            public string? Reason { get; set; }
        }
    }
}